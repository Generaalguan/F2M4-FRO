# ik ga uit leggen hoe de structuur in html er uit ziet van boven naar beneden.
## de aside is het eerst wat er is
### in de aside zit een nav 
#### daar zit een unorderdlist, met list items
#### in de nav zit ook een button
## dan komt de main
### daar zit een header in met titel en label
#### in de label zit een input
### daarna hebben we nog een unorderdlist
#### daar zit een button en een paragraaf in
