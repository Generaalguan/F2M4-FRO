# hoe werkt de kleuren cirkel animatie:
### de kleuren schema die hier bij is gebruikt is een cirkel, waardoor de kleuren na elkaar door blijven gaan

# wat vond ik leuk om te leren:
### ik vond het leren van hoe je een wazig efect kan maken